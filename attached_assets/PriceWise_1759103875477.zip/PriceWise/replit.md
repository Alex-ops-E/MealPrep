# Overview

Grocery Agent is an intelligent web application that serves as a complete kitchen and shopping assistant. The app combines AI-powered recipe generation with practical price comparison functionality across major retailers. Users can describe what they want to cook, receive AI-generated recipes with complete ingredients lists, and then seamlessly compare prices for those ingredients across Walmart and Amazon to find the best deals.

The application follows a guided workflow: Generate Recipe → View Recipe → Shop for Ingredients → Compare Prices, providing a seamless experience from cooking inspiration to cost-effective shopping.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: ShadCN/UI component library built on Radix UI primitives with Tailwind CSS for styling
- **State Management**: TanStack React Query for server state management and API interactions
- **Forms**: React Hook Form with Zod validation for type-safe form handling

## Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints for recipe generation, ingredient extraction, and price comparison
- **Development**: Hot module replacement with Vite in development mode
- **Production**: Compiled with esbuild for optimized server bundle

## Data Storage
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema**: Tables for users, recipes, and price comparisons with JSON fields for complex data
- **Development Storage**: In-memory storage implementation for development/testing
- **Migrations**: Drizzle Kit for database schema management

## AI Integration
- **Provider**: OpenAI GPT-5 for recipe generation and ingredient extraction
- **Recipe Generation**: Structured prompts that output JSON-formatted recipes with ingredients, instructions, and metadata
- **Ingredient Extraction**: AI-powered parsing of recipe text to create clean shopping lists

## External Dependencies
- **Neon Database**: Serverless PostgreSQL database hosting
- **OpenAI API**: GPT-5 model for AI-powered recipe generation and ingredient extraction
- **SerpApi**: Walmart product and pricing data via search API
- **RapidAPI**: Real-time Amazon product data and pricing information
- **Replit Services**: Development environment integration and deployment platform

## Price Comparison System
- **Multi-Retailer Support**: Walmart (via SerpApi) and Amazon (via RapidAPI)
- **Fallback Mechanism**: Estimated pricing when live API calls fail to ensure application reliability
- **Best Deal Detection**: Automatic identification of lowest prices per item and overall basket comparison
- **Real-time Data**: Live product searches and pricing from both retailers

## Authentication & Session Management
- **Session Storage**: PostgreSQL-based session management with connect-pg-simple
- **User Management**: Basic user authentication with password-based login system

## Development Tools
- **Type Safety**: Full TypeScript coverage across client, server, and shared code
- **Code Quality**: ESLint and Prettier for consistent code formatting
- **Path Aliases**: Organized imports with @ prefixes for clean code structure
- **Hot Reload**: Development server with instant updates for rapid iteration