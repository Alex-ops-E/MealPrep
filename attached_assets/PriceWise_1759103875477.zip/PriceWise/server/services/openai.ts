import OpenAI from "openai";

// Initialize OpenAI client
let openaiClient: OpenAI | null = null;
const apiKey = process.env.OPENAI_API_KEY;

if (apiKey) {
  try {
    openaiClient = new OpenAI({ 
      apiKey: apiKey
    });
    console.log("OpenAI client initialized successfully");
  } catch (error) {
    console.error(`Warning: Failed to initialize OpenAI client: ${error}`);
  }
} else {
  console.error("Warning: OPENAI_API_KEY environment variable not found");
}

export interface GenerateRecipeParams {
  description: string;
  servings?: string;
  cuisine?: string;
  cookingTime?: string;
  dietaryRestrictions?: string[];
}

export interface RecipeResponse {
  title: string;
  description: string;
  prepTime: string;
  servings: string;
  difficulty: string;
  ingredients: string[];
  instructions: string[];
  chefsTips: string;
}

export async function generateRecipe(params: GenerateRecipeParams): Promise<RecipeResponse> {
  try {
    // Check if OpenAI client is available
    if (!openaiClient) {
      throw new Error("OpenAI API is not properly configured. Please check your API key.");
    }

    const prompt = `Create a recipe for: ${params.description}
${params.servings ? `Servings: ${params.servings}` : ''}
${params.cuisine ? `Cuisine: ${params.cuisine}` : ''}
${params.cookingTime ? `Time: ${params.cookingTime}` : ''}
${params.dietaryRestrictions?.length ? `Dietary: ${params.dietaryRestrictions.join(', ')}` : ''}

Return JSON:
{
"title":"Recipe name",
"description":"Brief description",  
"prepTime":"25 minutes",
"servings":"4 servings",
"difficulty":"Easy/Medium/Hard",
"ingredients":["ingredient with amount"],
"instructions":["step by step"],
"chefsTips":"cooking tip"
}`;

    // Use gpt-3.5-turbo for faster response times
    const response = await openaiClient.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are a chef. Create practical recipes. Return only valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
      max_tokens: 1000,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return result as RecipeResponse;
  } catch (error) {
    console.error('Error generating recipe:', error);
    if (error instanceof Error) {
      throw new Error(`Recipe generation failed: ${error.message}`);
    }
    throw new Error("Failed to generate recipe. Please try again.");
  }
}

export async function extractIngredients(recipeText: string): Promise<string[]> {
  try {
    // Check if OpenAI client is available
    if (!openaiClient) {
      throw new Error("OpenAI API is not properly configured. Please check your API key.");
    }

    const prompt = `Extract ingredient names (no quantities) from: ${recipeText}
    
Example: "1 lb chicken breast" → "chicken breast"
Return JSON: {"ingredients": ["ingredient1", "ingredient2"]}`;

    const response = await openaiClient.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.1,
      max_tokens: 300,
    });

    const result = JSON.parse(response.choices[0].message.content || '{"ingredients": []}');
    return result.ingredients || [];
  } catch (error) {
    console.error('Error extracting ingredients:', error);
    if (error instanceof Error) {
      throw new Error(`Ingredient extraction failed: ${error.message}`);
    }
    throw new Error("Failed to extract ingredients. Please try again.");
  }
}
