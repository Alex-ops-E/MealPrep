import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateRecipe, extractIngredients } from "./services/openai";
import { compareGroceryPrices } from "./services/priceComparison";
import { recipeRequestSchema, priceComparisonRequestSchema, insertWaitlistEmailSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Recipe generation endpoint
  app.post("/api/recipes/generate", async (req, res) => {
    try {
      const validatedData = recipeRequestSchema.parse(req.body);
      
      const recipe = await generateRecipe({
        description: validatedData.description,
        servings: validatedData.servings,
        cuisine: validatedData.cuisine,
        cookingTime: validatedData.cookingTime,
        dietaryRestrictions: validatedData.dietaryRestrictions,
      });

      // Store the recipe
      const savedRecipe = await storage.createRecipe({
        title: recipe.title,
        description: recipe.description,
        prepTime: recipe.prepTime,
        servings: recipe.servings,
        difficulty: recipe.difficulty,
        ingredients: recipe.ingredients,
        instructions: recipe.instructions,
        chefsTips: recipe.chefsTips,
      });

      res.json(savedRecipe);
    } catch (error) {
      console.error("Error generating recipe:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to generate recipe" 
      });
    }
  });

  // Get recipe by ID
  app.get("/api/recipes/:id", async (req, res) => {
    try {
      const recipe = await storage.getRecipe(req.params.id);
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }
      res.json(recipe);
    } catch (error) {
      console.error("Error fetching recipe:", error);
      res.status(500).json({ message: "Failed to fetch recipe" });
    }
  });

  // Extract ingredients from recipe
  app.post("/api/recipes/:id/extract-ingredients", async (req, res) => {
    try {
      const recipe = await storage.getRecipe(req.params.id);
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }

      const recipeText = `${recipe.title}\n${recipe.description}\nIngredients: ${JSON.stringify(recipe.ingredients)}\nInstructions: ${JSON.stringify(recipe.instructions)}`;
      const ingredients = await extractIngredients(recipeText);
      
      res.json({ ingredients });
    } catch (error) {
      console.error("Error extracting ingredients:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to extract ingredients" 
      });
    }
  });

  // Price comparison endpoint
  app.post("/api/prices/compare", async (req, res) => {
    try {
      const validatedData = priceComparisonRequestSchema.parse(req.body);
      
      const comparison = await compareGroceryPrices(validatedData.ingredients);
      
      // Store the price comparison
      const savedComparison = await storage.createPriceComparison({
        ingredients: validatedData.ingredients,
        walmartTotal: comparison.walmartTotal.toString(),
        amazonTotal: comparison.amazonTotal.toString(),
        results: comparison.results,
      });

      res.json({
        id: savedComparison.id,
        ...comparison
      });
    } catch (error) {
      console.error("Error comparing prices:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to compare prices" 
      });
    }
  });

  // Get price comparison by ID
  app.get("/api/prices/:id", async (req, res) => {
    try {
      const comparison = await storage.getPriceComparison(req.params.id);
      if (!comparison) {
        return res.status(404).json({ message: "Price comparison not found" });
      }
      res.json(comparison);
    } catch (error) {
      console.error("Error fetching price comparison:", error);
      res.status(500).json({ message: "Failed to fetch price comparison" });
    }
  });

  // Add email to waitlist
  app.post("/api/waitlist", async (req, res) => {
    try {
      const validatedData = insertWaitlistEmailSchema.parse(req.body);
      
      // Check if email already exists
      const existingEmail = await storage.getWaitlistEmailByEmail(validatedData.email);
      if (existingEmail) {
        return res.status(409).json({ message: "Email already on waitlist" });
      }

      const savedEmail = await storage.addWaitlistEmail(validatedData);
      res.json({ 
        message: "Successfully added to waitlist",
        id: savedEmail.id 
      });
    } catch (error) {
      console.error("Error adding to waitlist:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to add to waitlist" 
      });
    }
  });

  // Get waitlist count (public endpoint for social proof)
  app.get("/api/waitlist/count", async (req, res) => {
    try {
      const emails = await storage.getAllWaitlistEmails();
      const count = emails.length;
      
      res.json({ count });
    } catch (error) {
      console.error("Error fetching waitlist count:", error);
      res.status(500).json({ message: "Failed to fetch waitlist count" });
    }
  });

  // Backend-only endpoint to log waitlist emails (protected)
  app.get("/api/admin/waitlist", async (req, res) => {
    try {
      // Basic protection - require a specific header or key
      const adminKey = req.headers['x-admin-key'];
      if (adminKey !== 'grocery-agent-admin-2024') {
        return res.status(403).json({ message: "Access denied" });
      }

      const emails = await storage.getAllWaitlistEmails();
      
      // Log emails to server console for admin viewing
      console.log('\n=== WAITLIST EMAILS ===');
      console.log(`Total emails: ${emails.length}`);
      console.log('Emails:');
      emails.forEach((email, index) => {
        console.log(`${index + 1}. ${email.email} (${new Date(email.createdAt!).toLocaleString()})`);
      });
      console.log('=====================\n');
      
      res.json({ 
        message: "Emails logged to server console",
        count: emails.length 
      });
    } catch (error) {
      console.error("Error fetching waitlist emails:", error);
      res.status(500).json({ message: "Failed to fetch waitlist emails" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
