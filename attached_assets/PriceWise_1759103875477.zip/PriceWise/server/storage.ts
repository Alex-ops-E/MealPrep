import { type User, type InsertUser, type Recipe, type InsertRecipe, type PriceComparison, type InsertPriceComparison, type WaitlistEmail, type InsertWaitlistEmail } from "@shared/schema";
import { users, recipes, priceComparisons, waitlistEmails } from "@shared/schema";
import { randomUUID } from "crypto";
import { drizzle } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getRecipe(id: string): Promise<Recipe | undefined>;
  createRecipe(recipe: InsertRecipe): Promise<Recipe>;
  
  getPriceComparison(id: string): Promise<PriceComparison | undefined>;
  createPriceComparison(comparison: InsertPriceComparison): Promise<PriceComparison>;
  
  addWaitlistEmail(email: InsertWaitlistEmail): Promise<WaitlistEmail>;
  getAllWaitlistEmails(): Promise<WaitlistEmail[]>;
  getWaitlistEmailByEmail(email: string): Promise<WaitlistEmail | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private recipes: Map<string, Recipe>;
  private priceComparisons: Map<string, PriceComparison>;
  private waitlistEmails: Map<string, WaitlistEmail>;

  constructor() {
    this.users = new Map();
    this.recipes = new Map();
    this.priceComparisons = new Map();
    this.waitlistEmails = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getRecipe(id: string): Promise<Recipe | undefined> {
    return this.recipes.get(id);
  }

  async createRecipe(insertRecipe: InsertRecipe): Promise<Recipe> {
    const id = randomUUID();
    const recipe: Recipe = { 
      ...insertRecipe,
      description: insertRecipe.description ?? null,
      servings: insertRecipe.servings ?? null,
      prepTime: insertRecipe.prepTime ?? null,
      difficulty: insertRecipe.difficulty ?? null,
      chefsTips: insertRecipe.chefsTips ?? null,
      id, 
      createdAt: new Date() 
    };
    this.recipes.set(id, recipe);
    return recipe;
  }

  async getPriceComparison(id: string): Promise<PriceComparison | undefined> {
    return this.priceComparisons.get(id);
  }

  async createPriceComparison(insertComparison: InsertPriceComparison): Promise<PriceComparison> {
    const id = randomUUID();
    const comparison: PriceComparison = { 
      ...insertComparison,
      walmartTotal: insertComparison.walmartTotal ?? null,
      amazonTotal: insertComparison.amazonTotal ?? null,
      id, 
      createdAt: new Date() 
    };
    this.priceComparisons.set(id, comparison);
    return comparison;
  }

  async addWaitlistEmail(insertEmail: InsertWaitlistEmail): Promise<WaitlistEmail> {
    const id = randomUUID();
    const waitlistEmail: WaitlistEmail = {
      ...insertEmail,
      id,
      createdAt: new Date()
    };
    this.waitlistEmails.set(id, waitlistEmail);
    return waitlistEmail;
  }

  async getAllWaitlistEmails(): Promise<WaitlistEmail[]> {
    return Array.from(this.waitlistEmails.values()).sort(
      (a, b) => b.createdAt!.getTime() - a.createdAt!.getTime()
    );
  }

  async getWaitlistEmailByEmail(email: string): Promise<WaitlistEmail | undefined> {
    return Array.from(this.waitlistEmails.values()).find(
      (waitlistEmail) => waitlistEmail.email === email
    );
  }
}

// PostgreSQL Storage Implementation
export class DBStorage implements IStorage {
  private db;

  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error("DATABASE_URL environment variable is required");
    }
    const sql = neon(process.env.DATABASE_URL);
    this.db = drizzle(sql);
  }

  async getUser(id: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await this.db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async getRecipe(id: string): Promise<Recipe | undefined> {
    const result = await this.db.select().from(recipes).where(eq(recipes.id, id));
    return result[0];
  }

  async createRecipe(insertRecipe: InsertRecipe): Promise<Recipe> {
    const result = await this.db.insert(recipes).values(insertRecipe).returning();
    return result[0];
  }

  async getPriceComparison(id: string): Promise<PriceComparison | undefined> {
    const result = await this.db.select().from(priceComparisons).where(eq(priceComparisons.id, id));
    return result[0];
  }

  async createPriceComparison(insertComparison: InsertPriceComparison): Promise<PriceComparison> {
    const result = await this.db.insert(priceComparisons).values(insertComparison).returning();
    return result[0];
  }

  async addWaitlistEmail(insertEmail: InsertWaitlistEmail): Promise<WaitlistEmail> {
    const result = await this.db.insert(waitlistEmails).values(insertEmail).returning();
    return result[0];
  }

  async getAllWaitlistEmails(): Promise<WaitlistEmail[]> {
    const result = await this.db.select().from(waitlistEmails).orderBy(waitlistEmails.createdAt);
    return result.reverse();
  }

  async getWaitlistEmailByEmail(email: string): Promise<WaitlistEmail | undefined> {
    const result = await this.db.select().from(waitlistEmails).where(eq(waitlistEmails.email, email));
    return result[0];
  }
}

// Use database storage instead of memory storage
export const storage = new DBStorage();
