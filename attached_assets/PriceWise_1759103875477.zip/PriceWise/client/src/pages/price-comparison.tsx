import { useState } from "react";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import PriceForm from "@/components/price-form";
import PriceResults from "@/components/price-results";

interface PriceComparisonResult {
  id: string;
  walmartTotal: number;
  amazonTotal: number;
  savings: number;
  savingsPercentage: number;
  bestOverall: 'walmart' | 'amazon';
  results: Array<{
    ingredient: string;
    walmart: { name: string; price: string; link: string; quantity?: string } | null;
    amazon: { name: string; price: string; link: string; quantity?: string } | null;
    bestDeal: 'walmart' | 'amazon' | 'tie';
  }>;
}

export default function PriceComparison() {
  const [currentResults, setCurrentResults] = useState<PriceComparisonResult | null>(null);

  return (
    <div className="min-h-screen bg-background">
      <Navigation currentPage="prices" />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-success/10 to-accent/5 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Smart Price Comparison
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Compare grocery prices across major retailers and save money on every shopping trip.
          </p>
        </div>
      </section>

      {/* Price Comparison Content */}
      <section className="py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {!currentResults ? (
            <PriceForm onResultsGenerated={setCurrentResults} />
          ) : (
            <PriceResults results={currentResults} onNewComparison={() => setCurrentResults(null)} />
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
