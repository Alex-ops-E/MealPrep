import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import IngredientsReview from "@/components/ingredients-review";

export default function IngredientsReviewPage() {
  const [, setLocation] = useLocation();
  const [ingredients, setIngredients] = useState<string[]>([]);

  // Get ingredients from URL params
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const ingredientsParam = urlParams.get('ingredients');
    if (ingredientsParam) {
      const ingredientsList = decodeURIComponent(ingredientsParam).split('\n').filter(item => item.trim());
      setIngredients(ingredientsList);
    }
  }, []);

  const handleStartOver = () => {
    setLocation('/recipes');
  };

  const handleComparePrices = (ingredientsList: string[]) => {
    const ingredientsParam = encodeURIComponent(ingredientsList.join('\n'));
    setLocation(`/prices?ingredients=${ingredientsParam}`);
  };

  if (ingredients.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <section className="py-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-2xl font-bold mb-4">No Ingredients Found</h2>
            <p className="text-muted-foreground mb-6">
              Please generate a recipe first to get ingredients for comparison.
            </p>
            <button
              onClick={handleStartOver}
              className="bg-primary text-primary-foreground px-6 py-2 rounded-md hover:bg-primary/90"
            >
              Generate Recipe
            </button>
          </div>
        </section>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 to-accent/5 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Review Your Shopping List
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Edit your ingredients list before comparing prices across retailers.
          </p>
        </div>
      </section>

      {/* Ingredients Review Content */}
      <section className="py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <IngredientsReview
            ingredients={ingredients}
            onStartOver={handleStartOver}
            onComparePrices={handleComparePrices}
          />
        </div>
      </section>

      <Footer />
    </div>
  );
}