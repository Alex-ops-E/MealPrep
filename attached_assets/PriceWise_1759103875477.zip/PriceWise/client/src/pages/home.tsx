import { Link } from "wouter";
import { useState, useEffect } from "react";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Utensils, DollarSign, Clock, Users, Smartphone, Bell, X } from "lucide-react";

export default function Home() {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [waitlistCount, setWaitlistCount] = useState(0);
  const [showMobileSticky, setShowMobileSticky] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [stickyDismissed, setStickyDismissed] = useState(false);
  const { toast } = useToast();

  // Fetch waitlist count on component mount
  useEffect(() => {
    const fetchWaitlistCount = async () => {
      try {
        const response = await fetch('/api/waitlist/count');
        if (response.ok) {
          const data = await response.json();
          setWaitlistCount(data.count || 0);
        }
      } catch (error) {
        console.log('Failed to fetch waitlist count, using fallback');
        // Fallback count will remain 0, shows static message
      }
    };
    
    fetchWaitlistCount();
    
    // Check localStorage for dismissed sticky
    const dismissed = localStorage.getItem('mobile-sticky-dismissed') === 'true';
    setStickyDismissed(dismissed);
    
    // Mobile sticky pill scroll handler
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      const shouldShow = scrollPosition > 600 && !dismissed; // Show after 600px scroll
      setShowMobileSticky(shouldShow);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleWaitlistSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsSubmitting(true);
    
    try {
      const response = await apiRequest("POST", "/api/waitlist", { email });
      
      if (response.ok) {
        toast({
          title: "You're on the waitlist!",
          description: "We'll notify you when the mobile app is ready.",
        });
        setEmail("");
        setIsDialogOpen(false); // Close dialog on success
        // Update count immediately after successful submission
        setWaitlistCount(prev => prev + 1);
      } else {
        const errorData = await response.json();
        if (response.status === 409) {
          toast({
            title: "Already on waitlist",
            description: "This email is already signed up for updates.",
            variant: "destructive",
          });
        } else {
          throw new Error(errorData.message || "Failed to join waitlist");
        }
      }
    } catch (error) {
      console.error("Error joining waitlist:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to join waitlist. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 to-accent/5 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
            Welcome to Grocery Agent
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Generate perfect recipes with AI and compare grocery prices across major retailers to save money on every meal.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-4">
            <Button asChild size="lg" data-testid="button-generate-recipe">
              <Link href="/recipes">
                <Utensils className="mr-2 h-5 w-5" />
                Generate Recipe
              </Link>
            </Button>
            <Button asChild size="lg" data-testid="button-compare-prices">
              <Link href="/prices">
                <DollarSign className="mr-2 h-5 w-5" />
                Compare Prices
              </Link>
            </Button>
          </div>
          <div className="text-sm text-muted-foreground">
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <button className="text-primary hover:underline" data-testid="button-mobile-app-link">
                  <Smartphone className="inline h-4 w-4 mr-1" />
                  Mobile app coming soon — join the waitlist
                </button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="flex items-center space-x-2">
                    <Smartphone className="h-5 w-5 text-primary" />
                    <span>Get Early Access to Mobile App</span>
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="text-sm text-muted-foreground">
                    <div className="space-y-2 mb-4">
                      <div className="grid grid-cols-1 gap-1 text-sm">
                        <span>✓ Price Alerts</span>
                        <span>✓ Smart Cart</span>
                        <span>✓ Pantry Sync</span>
                        <span>✓ Meal Planner</span>
                        <span>✓ Photo Scan and Cook</span>
                      </div>
                    </div>
                  </div>
                  <form onSubmit={handleWaitlistSubmit} className="space-y-3">
                    <Input
                      type="email"
                      placeholder="Enter your email address"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      data-testid="input-email-waitlist-dialog"
                    />
                    <Button 
                      type="submit" 
                      className="w-full" 
                      disabled={isSubmitting || !email}
                      data-testid="button-join-waitlist-dialog"
                    >
                      {isSubmitting ? "Joining waitlist..." : "Get Early Access — Free"}
                    </Button>
                  </form>
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <Users className="h-4 w-4" />
                    <span>1000+ people signed up</span>
                  </div>
                  <p className="text-xs text-muted-foreground text-center">
                    No spam. Unsubscribe anytime.
                  </p>
                </div>
              </DialogContent>
            </Dialog>
            <div className="flex items-center justify-center space-x-1 mt-1 text-xs text-muted-foreground">
              <Users className="h-3 w-3" />
              <span>1000+ people signed up</span>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="border-border shadow-sm" data-testid="card-recipe-generator">
              <CardContent className="p-8">
                <div className="flex items-center space-x-4 mb-6">
                  <div className="bg-primary/10 p-3 rounded-lg">
                    <Utensils className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-2xl font-semibold">AI Recipe Generator</h3>
                </div>
                <p className="text-muted-foreground mb-6">
                  Describe your craving and let AI create the perfect recipe for you. Complete with ingredients, instructions, and chef's tips.
                </p>
                <div className="space-y-3 mb-6">
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-primary" />
                    <span className="text-sm">Quick 30-minute meals</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Users className="h-4 w-4 text-primary" />
                    <span className="text-sm">Customizable servings</span>
                  </div>
                </div>
                <Button asChild className="w-full" data-testid="button-try-recipe-generator">
                  <Link href="/recipes">Try Recipe Generator</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="border-border shadow-sm" data-testid="card-price-comparison">
              <CardContent className="p-8">
                <div className="flex items-center space-x-4 mb-6">
                  <div className="bg-success/10 p-3 rounded-lg">
                    <DollarSign className="h-8 w-8 text-success" />
                  </div>
                  <h3 className="text-2xl font-semibold">Smart Price Comparison</h3>
                </div>
                <p className="text-muted-foreground mb-6">
                  Compare grocery prices across Walmart and Amazon. Find the best deals and save money on every shopping trip.
                </p>
                <div className="space-y-3 mb-6">
                  <div className="flex items-center space-x-2">
                    <DollarSign className="h-4 w-4 text-success" />
                    <span className="text-sm">Real-time price tracking</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <DollarSign className="h-4 w-4 text-success" />
                    <span className="text-sm">Best value highlighting</span>
                  </div>
                </div>
                <Button asChild className="w-full" data-testid="button-try-price-comparison">
                  <Link href="/prices">Try Price Comparison</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Mobile App Details Section - Compact */}
      <section className="bg-gradient-to-r from-primary/5 to-accent/3 py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
            <Smartphone className="h-6 w-6 text-primary" />
          </div>
          <h2 className="text-xl md:text-2xl font-semibold text-foreground mb-3">
            Mobile App Coming Soon
          </h2>
          <p className="text-sm text-muted-foreground mb-6 max-w-lg mx-auto">
            Get Grocery Agent on your phone with exclusive mobile features.
          </p>
          
          <div className="grid md:grid-cols-3 gap-4 mb-6">
            <div className="text-center">
              <div className="bg-blue-500/10 w-8 h-8 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Bell className="h-4 w-4 text-blue-600" />
              </div>
              <h3 className="text-sm font-semibold mb-1">Price Alerts</h3>
              <p className="text-xs text-muted-foreground">Get notified when items go on sale</p>
            </div>
            <div className="text-center">
              <div className="bg-green-500/10 w-8 h-8 rounded-lg flex items-center justify-center mx-auto mb-2">
                <DollarSign className="h-4 w-4 text-green-600" />
              </div>
              <h3 className="text-sm font-semibold mb-1">Smart Cart</h3>
              <p className="text-xs text-muted-foreground">Find the best store for your list</p>
            </div>
            <div className="text-center">
              <div className="bg-purple-500/10 w-8 h-8 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Utensils className="h-4 w-4 text-purple-600" />
              </div>
              <h3 className="text-sm font-semibold mb-1">Pantry Sync</h3>
              <p className="text-xs text-muted-foreground">Track ingredients and get suggestions</p>
            </div>
          </div>
          
          {/* Compact waitlist form */}
          <Card className="max-w-sm mx-auto bg-card/30 border border-border/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-center space-x-2 mb-3">
                <Users className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">
                  1000+ people joined
                </span>
              </div>
              <form onSubmit={handleWaitlistSubmit} className="flex space-x-2">
                <Input
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="text-sm"
                  data-testid="input-email-waitlist-section"
                />
                <Button 
                  type="submit" 
                  size="sm"
                  disabled={isSubmitting || !email}
                  data-testid="button-join-waitlist-section"
                >
                  {isSubmitting ? "..." : "Join"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
      
      {/* Mobile Sticky Pill */}
      {showMobileSticky && !stickyDismissed && (
        <div className="fixed bottom-4 left-4 right-4 z-50 lg:hidden">
          <Dialog>
            <div className="bg-primary/95 backdrop-blur-sm rounded-full px-4 py-3 shadow-lg flex items-center justify-between">
              <DialogTrigger asChild>
                <div className="flex items-center space-x-2 flex-1 cursor-pointer">
                  <Smartphone className="h-4 w-4 text-primary-foreground" />
                  <span className="text-sm font-medium text-primary-foreground">Get mobile app updates</span>
                </div>
              </DialogTrigger>
              <button 
                onClick={() => {
                  setStickyDismissed(true);
                  setShowMobileSticky(false);
                  localStorage.setItem('mobile-sticky-dismissed', 'true');
                }}
                className="ml-2 text-primary-foreground/70 hover:text-primary-foreground"
                data-testid="button-dismiss-sticky"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="flex items-center space-x-2">
                  <Smartphone className="h-5 w-5 text-primary" />
                  <span>Get Early Access to Mobile App</span>
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="text-sm text-muted-foreground">
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center space-x-2">
                      <span>✓ Price Alerts</span>
                      <span>✓ Smart Cart</span>
                      <span>✓ Pantry Sync</span>
                    </div>
                  </div>
                </div>
                <form onSubmit={handleWaitlistSubmit} className="space-y-3">
                  <Input
                    type="email"
                    placeholder="Enter your email address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    data-testid="input-email-mobile-dialog"
                  />
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={isSubmitting || !email}
                    data-testid="button-join-mobile-dialog"
                  >
                    {isSubmitting ? "Joining waitlist..." : "Get Early Access — Free"}
                  </Button>
                </form>
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <Users className="h-4 w-4" />
                  <span>
                    {waitlistCount >= 1000 
                      ? `Already ${Math.floor(waitlistCount / 100) * 100}+ people signed up`
                      : waitlistCount > 0 
                      ? `Join ${waitlistCount} smart shoppers already on the list`
                      : "Already 1,000+ people signed up"
                    }
                  </span>
                </div>
                <p className="text-xs text-muted-foreground text-center">
                  No spam. Unsubscribe anytime.
                </p>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      )}
    </div>
  );
}
