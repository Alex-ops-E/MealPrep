import { useState } from "react";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import RecipeForm from "@/components/recipe-form";
import RecipeDisplay from "@/components/recipe-display";
import { Recipe } from "@shared/schema";

export default function RecipeGenerator() {
  const [currentRecipe, setCurrentRecipe] = useState<Recipe | null>(null);

  return (
    <div className="min-h-screen bg-background">
      <Navigation currentPage="recipes" />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 to-accent/5 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            AI-Powered Recipe Discovery
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            From craving to cost-effective shopping list in minutes. Let AI create the perfect recipe for you.
          </p>
        </div>
      </section>

      {/* Recipe Generation Flow */}
      <section className="py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Step Indicator */}
          <div className="flex items-center justify-center mb-12">
            <div className="flex items-center space-x-4">
              <div className="flex flex-col items-center">
                <div className={`step-indicator ${currentRecipe ? 'step-completed' : 'step-active'}`} data-testid="step-generate">1</div>
                <span className={`text-sm mt-2 ${currentRecipe ? 'text-success font-medium' : 'text-primary font-medium'}`}>Generate</span>
              </div>
              <div className="w-12 h-0.5 bg-border"></div>
              <div className="flex flex-col items-center">
                <div className={`step-indicator ${currentRecipe ? 'step-active' : 'step-pending'}`} data-testid="step-view">2</div>
                <span className={`text-sm mt-2 ${currentRecipe ? 'text-primary font-medium' : 'text-muted-foreground'}`}>View Recipe</span>
              </div>
              <div className="w-12 h-0.5 bg-border"></div>
              <div className="flex flex-col items-center">
                <div className="step-indicator step-pending" data-testid="step-shop">3</div>
                <span className="text-sm mt-2 text-muted-foreground">Shop</span>
              </div>
              <div className="w-12 h-0.5 bg-border"></div>
              <div className="flex flex-col items-center">
                <div className="step-indicator step-pending" data-testid="step-compare">4</div>
                <span className="text-sm mt-2 text-muted-foreground">Compare</span>
              </div>
            </div>
          </div>

          {!currentRecipe ? (
            <RecipeForm onRecipeGenerated={setCurrentRecipe} />
          ) : (
            <RecipeDisplay recipe={currentRecipe} onNewRecipe={() => setCurrentRecipe(null)} />
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
