import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, ShoppingCart, RotateCcw } from "lucide-react";

interface IngredientsReviewProps {
  ingredients: string[];
  onStartOver: () => void;
  onComparePrices: (ingredientsList: string[]) => void;
}

export default function IngredientsReview({ ingredients, onStartOver, onComparePrices }: IngredientsReviewProps) {
  const [ingredientsList, setIngredientsList] = useState<string[]>(ingredients);

  const removeIngredient = (index: number) => {
    setIngredientsList(ingredientsList.filter((_, i) => i !== index));
  };

  const handleComparePrices = () => {
    onComparePrices(ingredientsList);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="bg-card rounded-lg border border-border p-8 shadow-sm">
        <div className="mb-8">
          <div className="flex items-center space-x-2 mb-2">
            <span className="text-primary">📝</span>
            <h3 className="text-2xl font-semibold">Review Ingredients ({ingredientsList.length})</h3>
          </div>
          <p className="text-muted-foreground">
            Review and edit the ingredients before comparing prices
          </p>
        </div>

        <div className="space-y-3 mb-8">
          {ingredientsList.map((ingredient, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-4 bg-secondary/30 rounded-lg border border-border/30"
              data-testid={`ingredient-item-${index}`}
            >
              <div className="flex items-center space-x-3">
                <span className="text-primary font-medium">{index + 1}.</span>
                <span className="text-foreground">{ingredient}</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => removeIngredient(index)}
                className="text-destructive hover:text-destructive hover:bg-destructive/10"
                data-testid={`button-remove-${index}`}
              >
                <X className="h-4 w-4 mr-1" />
                Remove
              </Button>
            </div>
          ))}
        </div>

        {ingredientsList.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <p>No ingredients to compare. Please start over to generate a new recipe.</p>
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            variant="outline"
            onClick={onStartOver}
            className="flex-1 sm:flex-none"
            data-testid="button-start-over"
          >
            <RotateCcw className="mr-2 h-4 w-4" />
            Start Over
          </Button>
          <Button
            onClick={handleComparePrices}
            disabled={ingredientsList.length === 0}
            className="flex-1 sm:flex-none"
            data-testid="button-compare-prices"
          >
            <ShoppingCart className="mr-2 h-4 w-4" />
            Compare Prices
          </Button>
        </div>
      </Card>
    </div>
  );
}