import { Link, useLocation } from "wouter";
import { Utensils } from "lucide-react";
import { Button } from "@/components/ui/button";

interface NavigationProps {
  currentPage?: string;
}

export default function Navigation({ currentPage }: NavigationProps) {
  const [location] = useLocation();

  const isActive = (path: string) => {
    if (currentPage) {
      return currentPage === path;
    }
    return location === `/${path}` || (path === 'home' && location === '/');
  };

  return (
    <nav className="bg-card border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center space-x-4" data-testid="link-home">
            <Utensils className="text-primary text-2xl" />
            <h1 className="text-xl font-bold text-foreground">Grocery Agent</h1>
          </Link>
          
          <div className="hidden md:flex space-x-6">
            <Button
              asChild
              variant={isActive('recipes') ? 'default' : 'ghost'}
              data-testid="nav-recipes"
            >
              <Link href="/recipes">Recipe Generator</Link>
            </Button>
            <Button
              asChild
              variant={isActive('prices') ? 'default' : 'ghost'}
              data-testid="nav-prices"
            >
              <Link href="/prices">Price Comparison</Link>
            </Button>
          </div>
          
          <div className="md:hidden">
            <Button variant="ghost" size="sm">
              <i className="fas fa-bars"></i>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
