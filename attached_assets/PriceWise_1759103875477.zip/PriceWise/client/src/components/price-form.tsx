import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Search, Info } from "lucide-react";

interface PriceFormProps {
  onResultsGenerated: (results: any) => void;
}

export default function PriceForm({ onResultsGenerated }: PriceFormProps) {
  const { toast } = useToast();
  const [location] = useLocation();
  const [ingredients, setIngredients] = useState("");

  // Check for pre-filled ingredients from URL params
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const prefilledIngredients = urlParams.get('ingredients');
    if (prefilledIngredients) {
      setIngredients(decodeURIComponent(prefilledIngredients));
    }
  }, [location]);

  const comparePricesMutation = useMutation({
    mutationFn: async (ingredientsList: string[]) => {
      const response = await apiRequest("POST", "/api/prices/compare", {
        ingredients: ingredientsList,
      });
      return await response.json();
    },
    onSuccess: (results) => {
      toast({
        title: "Prices Compared!",
        description: "Found the best deals across retailers.",
      });
      onResultsGenerated(results);
    },
    onError: (error) => {
      toast({
        title: "Comparison Failed",
        description: error.message || "Failed to compare prices. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!ingredients.trim()) {
      toast({
        title: "No Ingredients",
        description: "Please enter at least one ingredient to compare prices.",
        variant: "destructive",
      });
      return;
    }

    const ingredientsList = ingredients
      .split('\n')
      .map(item => item.trim())
      .filter(item => item.length > 0);

    if (ingredientsList.length === 0) {
      toast({
        title: "No Valid Ingredients",
        description: "Please enter valid ingredients to compare prices.",
        variant: "destructive",
      });
      return;
    }

    comparePricesMutation.mutate(ingredientsList);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="bg-card rounded-lg border border-border p-8 shadow-sm">
        <h3 className="text-2xl font-semibold mb-6">Enter Your Shopping List</h3>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Ingredients Input */}
          <div>
            <Label htmlFor="ingredients" className="block text-sm font-medium mb-2">
              Ingredients (one per line)
            </Label>
            <Textarea
              id="ingredients"
              value={ingredients}
              onChange={(e) => setIngredients(e.target.value)}
              placeholder="boneless chicken breast&#10;penne pasta&#10;heavy cream&#10;garlic&#10;parmesan cheese&#10;fresh basil&#10;olive oil"
              rows={8}
              className="resize-none"
              data-testid="input-ingredients"
            />
            <div className="flex items-center mt-2 text-sm text-muted-foreground">
              <Info className="h-4 w-4 mr-1" />
              You can include quantities (e.g., "2 lbs chicken breast") or just the item name
            </div>
          </div>

          {/* Compare Button */}
          <Button
            type="submit"
            className="w-full"
            size="lg"
            disabled={comparePricesMutation.isPending}
            data-testid="button-compare-prices"
          >
            {comparePricesMutation.isPending ? (
              "Comparing Prices..."
            ) : (
              <>
                <Search className="mr-2 h-5 w-5" />
                Compare Prices
              </>
            )}
          </Button>
        </form>
      </Card>
    </div>
  );
}
