import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { recipeRequestSchema, type RecipeRequest, type Recipe } from "@shared/schema";
import { Sparkles } from "lucide-react";

interface RecipeFormProps {
  onRecipeGenerated: (recipe: Recipe) => void;
}

const quickStarts = [
  { label: "Healthy & Quick", value: "a healthy 30-minute meal with lean protein and vegetables" },
  { label: "Comfort Food", value: "a hearty comfort food dish that's warm and satisfying" },
  { label: "Date Night", value: "an elegant romantic dinner for two people" },
  { label: "Family Dinner", value: "a family-friendly dinner that everyone will enjoy" },
];

const dietaryOptions = [
  "Vegetarian",
  "Vegan", 
  "Gluten-Free",
  "Dairy-Free",
  "Keto",
];

export default function RecipeForm({ onRecipeGenerated }: RecipeFormProps) {
  const { toast } = useToast();
  const [selectedDietaryRestrictions, setSelectedDietaryRestrictions] = useState<string[]>([]);

  const form = useForm<RecipeRequest>({
    resolver: zodResolver(recipeRequestSchema),
    defaultValues: {
      description: "",
      servings: "4 people",
      cuisine: "Any",
      cookingTime: "Any",
      dietaryRestrictions: [],
    },
  });

  const generateRecipeMutation = useMutation({
    mutationFn: async (data: RecipeRequest) => {
      const response = await apiRequest("POST", "/api/recipes/generate", data);
      return await response.json();
    },
    onSuccess: (recipe: Recipe) => {
      toast({
        title: "Recipe Generated!",
        description: "Your personalized recipe is ready.",
      });
      onRecipeGenerated(recipe);
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate recipe. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleQuickStart = (value: string) => {
    form.setValue("description", value);
  };

  const handleDietaryChange = (restriction: string, checked: boolean) => {
    const updated = checked
      ? [...selectedDietaryRestrictions, restriction]
      : selectedDietaryRestrictions.filter(r => r !== restriction);
    
    setSelectedDietaryRestrictions(updated);
    form.setValue("dietaryRestrictions", updated);
  };

  const onSubmit = (data: RecipeRequest) => {
    generateRecipeMutation.mutate(data);
  };

  return (
    <Card className="bg-card rounded-lg border border-border p-8 shadow-sm">
      <h3 className="text-2xl font-semibold mb-6">What would you like to cook?</h3>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Main Input */}
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Describe your craving</FormLabel>
                <FormControl>
                  <Textarea
                    {...field}
                    placeholder="e.g., a healthy 30-minute chicken meal for dinner"
                    rows={3}
                    className="resize-none"
                    data-testid="input-description"
                  />
                </FormControl>
              </FormItem>
            )}
          />

          {/* Quick Start Buttons */}
          <div>
            <FormLabel className="block mb-3">Quick starts</FormLabel>
            <div className="flex flex-wrap gap-2">
              {quickStarts.map((quickStart) => (
                <Button
                  key={quickStart.label}
                  type="button"
                  variant="secondary"
                  onClick={() => handleQuickStart(quickStart.value)}
                  data-testid={`button-quickstart-${quickStart.label.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  {quickStart.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Recipe Preferences */}
          <div className="grid md:grid-cols-3 gap-6">
            <FormField
              control={form.control}
              name="servings"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Servings</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-servings">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="2 people">2 people</SelectItem>
                      <SelectItem value="4 people">4 people</SelectItem>
                      <SelectItem value="6 people">6 people</SelectItem>
                      <SelectItem value="8 people">8 people</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="cuisine"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Cuisine Style</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-cuisine">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Any">Any</SelectItem>
                      <SelectItem value="Italian">Italian</SelectItem>
                      <SelectItem value="Asian">Asian</SelectItem>
                      <SelectItem value="Mexican">Mexican</SelectItem>
                      <SelectItem value="Mediterranean">Mediterranean</SelectItem>
                      <SelectItem value="American">American</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="cookingTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Cooking Time</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-cooking-time">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Any">Any</SelectItem>
                      <SelectItem value="Under 30 min">Under 30 min</SelectItem>
                      <SelectItem value="30-60 min">30-60 min</SelectItem>
                      <SelectItem value="1-2 hours">1-2 hours</SelectItem>
                      <SelectItem value="2+ hours">2+ hours</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />
          </div>

          {/* Dietary Restrictions */}
          <div>
            <FormLabel className="block mb-3">Dietary Restrictions</FormLabel>
            <div className="flex flex-wrap gap-4">
              {dietaryOptions.map((restriction) => (
                <div key={restriction} className="flex items-center space-x-2">
                  <Checkbox
                    id={restriction}
                    checked={selectedDietaryRestrictions.includes(restriction)}
                    onCheckedChange={(checked) => handleDietaryChange(restriction, !!checked)}
                    data-testid={`checkbox-${restriction.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
                  />
                  <label htmlFor={restriction} className="text-sm font-medium">
                    {restriction}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Generate Button */}
          <Button
            type="submit"
            className="w-full"
            size="lg"
            disabled={generateRecipeMutation.isPending}
            data-testid="button-generate-recipe"
          >
            {generateRecipeMutation.isPending ? (
              "Generating Recipe..."
            ) : (
              <>
                <Sparkles className="mr-2 h-5 w-5" />
                Generate Recipe with AI
              </>
            )}
          </Button>
        </form>
      </Form>
    </Card>
  );
}
