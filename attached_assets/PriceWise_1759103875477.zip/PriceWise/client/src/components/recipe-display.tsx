import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { type Recipe } from "@shared/schema";
import { Clock, Users, BarChart3, ShoppingCart, Bookmark, Share2, Lightbulb } from "lucide-react";

interface RecipeDisplayProps {
  recipe: Recipe;
  onNewRecipe: () => void;
}

export default function RecipeDisplay({ recipe, onNewRecipe }: RecipeDisplayProps) {
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const extractIngredientsMutation = useMutation({
    mutationFn: async (recipeId: string) => {
      const response = await apiRequest("POST", `/api/recipes/${recipeId}/extract-ingredients`);
      return await response.json();
    },
    onSuccess: (data) => {
      // Navigate to ingredients review with pre-filled ingredients
      setLocation(`/ingredients?ingredients=${encodeURIComponent(data.ingredients.join('\n'))}`);
    },
    onError: (error) => {
      toast({
        title: "Extraction Failed",
        description: error.message || "Failed to extract ingredients. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleShopForIngredients = () => {
    extractIngredientsMutation.mutate(recipe.id);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: recipe.title,
          text: recipe.description || recipe.title,
          url: window.location.href,
        });
      } catch (error) {
        // User cancelled sharing
      }
    } else {
      // Fallback: copy to clipboard
      await navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link Copied!",
        description: "Recipe link copied to clipboard.",
      });
    }
  };

  const ingredients = Array.isArray(recipe.ingredients) ? recipe.ingredients : [];
  const instructions = Array.isArray(recipe.instructions) ? recipe.instructions : [];

  return (
    <div className="bg-secondary/30" data-testid="recipe-display">
      <Card className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
        {/* Recipe Header */}
        <div className="relative">
          <img 
            src="https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=600"
            alt={recipe.title}
            className="w-full h-64 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          <div className="absolute bottom-6 left-6 text-white">
            <h3 className="text-3xl font-bold mb-2" data-testid="text-recipe-title">{recipe.title}</h3>
            <div className="flex items-center space-x-4 text-sm">
              <span className="flex items-center space-x-1">
                <Clock className="h-4 w-4" />
                <span data-testid="text-prep-time">{recipe.prepTime}</span>
              </span>
              <span className="flex items-center space-x-1">
                <Users className="h-4 w-4" />
                <span data-testid="text-servings">{recipe.servings}</span>
              </span>
              <span className="flex items-center space-x-1">
                <BarChart3 className="h-4 w-4" />
                <span data-testid="text-difficulty">{recipe.difficulty}</span>
              </span>
            </div>
          </div>
          <Button
            variant="secondary"
            size="sm"
            className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm hover:bg-white/30"
            onClick={handleShare}
            data-testid="button-share"
          >
            <Share2 className="h-4 w-4" />
          </Button>
        </div>

        <CardContent className="p-8">
          {/* Recipe Description */}
          <p className="text-muted-foreground mb-8" data-testid="text-recipe-description">
            {recipe.description}
          </p>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Ingredients */}
            <div className="lg:col-span-1">
              <h4 className="text-xl font-semibold mb-4">Ingredients</h4>
              <ul className="space-y-3" data-testid="list-ingredients">
                {ingredients.map((ingredient, index) => (
                  <li key={index} className="flex items-center space-x-3">
                    <span className="w-2 h-2 bg-primary rounded-full"></span>
                    <span>{ingredient}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Instructions */}
            <div className="lg:col-span-2">
              <h4 className="text-xl font-semibold mb-4">Instructions</h4>
              <div className="space-y-6 recipe-steps" data-testid="list-instructions">
                {instructions.map((instruction, index) => (
                  <div key={index} className="recipe-step flex">
                    <p className="text-muted-foreground">{instruction}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Chef's Tips */}
          {recipe.chefsTips && (
            <div className="mt-8 p-4 bg-accent rounded-lg">
              <h5 className="font-semibold mb-2 flex items-center space-x-2">
                <Lightbulb className="h-4 w-4 text-primary" />
                <span>Chef's Tips</span>
              </h5>
              <p className="text-sm text-muted-foreground" data-testid="text-chefs-tips">
                {recipe.chefsTips}
              </p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 mt-8">
            <Button
              onClick={handleShopForIngredients}
              disabled={extractIngredientsMutation.isPending}
              className="flex-1"
              data-testid="button-shop-ingredients"
            >
              <ShoppingCart className="mr-2 h-4 w-4" />
              {extractIngredientsMutation.isPending ? "Preparing..." : "Shop for Ingredients"}
            </Button>
            <Button variant="secondary" onClick={onNewRecipe} className="flex-1" data-testid="button-new-recipe">
              Generate New Recipe
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
