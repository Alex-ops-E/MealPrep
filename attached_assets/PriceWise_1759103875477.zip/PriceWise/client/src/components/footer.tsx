import { Link } from "wouter";
import { Utensils } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-card border-t border-border py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Utensils className="text-primary text-xl" />
              <span className="font-bold text-lg">Grocery Agent</span>
            </div>
            <p className="text-muted-foreground text-sm">
              Your intelligent kitchen and shopping assistant, powered by AI.
            </p>
          </div>
          <div>
            <h5 className="font-semibold mb-4">Features</h5>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/recipes" className="hover:text-foreground">Recipe Generator</Link></li>
              <li><Link href="/prices" className="hover:text-foreground">Price Comparison</Link></li>
              <li><a href="#" className="hover:text-foreground">Shopping Lists</a></li>
              <li><a href="#" className="hover:text-foreground">Meal Planning</a></li>
            </ul>
          </div>
          <div>
            <h5 className="font-semibold mb-4">Support</h5>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-foreground">Help Center</a></li>
              <li><a href="#" className="hover:text-foreground">Contact Us</a></li>
              <li><a href="#" className="hover:text-foreground">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-foreground">Terms of Service</a></li>
            </ul>
          </div>
          <div>
            <h5 className="font-semibold mb-4">Connect</h5>
            <div className="flex space-x-4">
              <a href="#" className="text-muted-foreground hover:text-foreground">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground">
                <i className="fab fa-facebook"></i>
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground">
                <i className="fab fa-instagram"></i>
              </a>
            </div>
          </div>
        </div>
        <div className="border-t border-border mt-8 pt-8">
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="text-center">
              <h6 className="font-semibold text-foreground mb-3">Disclaimer</h6>
              <p className="text-sm text-muted-foreground mb-4">
                Grocery Agent is an experimental tool that helps users compare prices across retailers. We are not affiliated with or endorsed by Walmart or Amazon. Prices and availability may vary and are provided via third-party APIs.
              </p>
            </div>
            <div className="text-center">
              <h6 className="font-semibold text-foreground mb-3">Terms of Use</h6>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>This tool is provided as-is and for informational purposes only.</li>
                <li>Do not rely on price or availability data for any purchasing decisions.</li>
                <li>Tool uses third-party APIs for demonstration purposes only. No guarantee of data accuracy or availability.</li>
              </ul>
            </div>
            <div className="text-center text-sm text-muted-foreground border-t border-border pt-4">
              © 2024 Grocery Agent. All rights reserved.
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
