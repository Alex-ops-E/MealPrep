import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Store, ShoppingBasket, FileText, Crown, ExternalLink } from "lucide-react";

interface PriceResultsProps {
  results: {
    id: string;
    walmartTotal: number;
    amazonTotal: number;
    savings: number;
    savingsPercentage: number;
    bestOverall: 'walmart' | 'amazon';
    results: Array<{
      ingredient: string;
      walmart: { name: string; price: string; link: string; quantity?: string } | null;
      amazon: { name: string; price: string; link: string; quantity?: string } | null;
      bestDeal: 'walmart' | 'amazon' | 'tie';
    }>;
  };
  onNewComparison: () => void;
}

export default function PriceResults({ results, onNewComparison }: PriceResultsProps) {
  const formatPrice = (price: number) => `$${price.toFixed(2)}`;

  return (
    <div className="space-y-8" data-testid="price-results">
      {/* Total Cost Cards */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card className={`relative border ${results.bestOverall === 'walmart' ? 'border-success' : 'border-border'}`}>
          {results.bestOverall === 'walmart' && (
            <div className="best-value-badge">
              <Crown className="h-3 w-3 mr-1" />
              Best Value
            </div>
          )}
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <Store className="h-8 w-8 text-blue-600" />
                <h4 className="text-xl font-semibold">Walmart</h4>
              </div>
              <div className="text-right">
                <div className={`text-3xl font-bold ${results.bestOverall === 'walmart' ? 'text-success' : 'text-foreground'}`} data-testid="price-walmart-total">
                  {formatPrice(results.walmartTotal)}
                </div>
                <div className="text-sm text-muted-foreground">Total basket cost</div>
              </div>
            </div>
            {results.bestOverall === 'walmart' && (
              <div className="text-sm text-success font-medium">
                Save {formatPrice(results.savings)} ({results.savingsPercentage.toFixed(1)}%) vs Amazon
              </div>
            )}
          </CardContent>
        </Card>

        <Card className={`relative border ${results.bestOverall === 'amazon' ? 'border-success' : 'border-border'}`}>
          {results.bestOverall === 'amazon' && (
            <div className="best-value-badge">
              <Crown className="h-3 w-3 mr-1" />
              Best Value
            </div>
          )}
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <ShoppingBasket className="h-8 w-8 text-orange-500" />
                <h4 className="text-xl font-semibold">Amazon</h4>
              </div>
              <div className="text-right">
                <div className={`text-3xl font-bold ${results.bestOverall === 'amazon' ? 'text-success' : 'text-foreground'}`} data-testid="price-amazon-total">
                  {formatPrice(results.amazonTotal)}
                </div>
                <div className="text-sm text-muted-foreground">Total basket cost</div>
              </div>
            </div>
            {results.bestOverall === 'amazon' && (
              <div className="text-sm text-success font-medium">
                Save {formatPrice(results.savings)} ({results.savingsPercentage.toFixed(1)}%) vs Walmart
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Detailed Price Breakdown */}
      <Card className="shadow-sm">
        <CardContent className="p-6">
          <div className="mb-6">
            <h4 className="text-xl font-semibold">Detailed Price Breakdown</h4>
            <p className="text-muted-foreground mt-1">Compare individual item prices across retailers</p>
          </div>
          
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Item</TableHead>
                  <TableHead>Walmart</TableHead>
                  <TableHead>Amazon</TableHead>
                  <TableHead>Best Deal</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {results.results.map((item, index) => (
                  <TableRow key={index} className="hover:bg-accent/50" data-testid={`row-item-${index}`}>
                    <TableCell>
                      <div className="font-medium">{item.ingredient}</div>
                      {item.walmart?.quantity && (
                        <div className="text-sm text-muted-foreground">{item.walmart.quantity}</div>
                      )}
                    </TableCell>
                    <TableCell>
                      {item.walmart ? (
                        <div>
                          <div className="font-medium" data-testid={`price-walmart-${index}`}>{item.walmart.price}</div>
                          <a 
                            href={item.walmart.link} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-sm text-primary hover:underline inline-flex items-center"
                            data-testid={`link-walmart-${index}`}
                          >
                            View product <ExternalLink className="h-3 w-3 ml-1" />
                          </a>
                        </div>
                      ) : (
                        <span className="text-muted-foreground">Not available</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {item.amazon ? (
                        <div>
                          <div className="font-medium" data-testid={`price-amazon-${index}`}>{item.amazon.price}</div>
                          {item.amazon.link !== '#' && (
                            <a 
                              href={item.amazon.link} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-sm text-primary hover:underline inline-flex items-center"
                              data-testid={`link-amazon-${index}`}
                            >
                              View product <ExternalLink className="h-3 w-3 ml-1" />
                            </a>
                          )}
                        </div>
                      ) : (
                        <span className="text-muted-foreground">Not available</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {item.bestDeal === 'walmart' && (
                        <Badge variant="outline" className="bg-blue-50 text-blue-800 border-blue-200" data-testid={`badge-best-walmart-${index}`}>
                          <Store className="h-3 w-3 mr-1" />
                          Walmart
                        </Badge>
                      )}
                      {item.bestDeal === 'amazon' && (
                        <Badge variant="outline" className="bg-success/10 text-success border-success/20" data-testid={`badge-best-amazon-${index}`}>
                          <ShoppingBasket className="h-3 w-3 mr-1" />
                          Amazon
                        </Badge>
                      )}
                      {item.bestDeal === 'tie' && (
                        <Badge variant="outline" data-testid={`badge-tie-${index}`}>
                          Tie
                        </Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Shopping Actions */}
      <div className="flex flex-col sm:flex-row gap-4">
        <Button className="flex-1 bg-blue-600 hover:bg-blue-700" data-testid="button-shop-walmart">
          <Store className="mr-2 h-4 w-4" />
          Shop at Walmart
        </Button>
        <Button className="flex-1 bg-orange-500 hover:bg-orange-600" data-testid="button-shop-amazon">
          <ShoppingBasket className="mr-2 h-4 w-4" />
          Shop at Amazon
        </Button>
        <Button variant="secondary" className="flex-1" data-testid="button-export-list">
          <FileText className="mr-2 h-4 w-4" />
          Export List
        </Button>
        <Button variant="outline" onClick={onNewComparison} data-testid="button-new-comparison">
          New Comparison
        </Button>
      </div>
    </div>
  );
}
